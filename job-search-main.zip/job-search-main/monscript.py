class Monscript:
  def __init__(self,name):
    self.name=name
  def executer():
    print("executer mon scipt ici")
  def lire():
    print("executer mon scipt ici")
  def enregistrer():
    print("executer mon scipt ici")
