class Person:
  def __init__(self,name):
    self.name=name
  def saluer(self):
    return "Bonjour, "+self.name+" !"
  def saluer_autre(self):
    return "Salut, "+self.name+" !"
