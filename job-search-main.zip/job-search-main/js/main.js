$(function(){
$('.carousel').carousel("cycle");

});
