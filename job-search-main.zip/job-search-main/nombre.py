class Nombre:
  def __init__(self,nombre):
    self.nombre=nombre
  def additionner_avec(self,nombre):
    return (self.nombre+nombre)
  def moins_nombre(self,nombre):
    return (self.nombre-nombre)
