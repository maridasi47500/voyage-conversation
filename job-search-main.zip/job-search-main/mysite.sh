python3 server.py
