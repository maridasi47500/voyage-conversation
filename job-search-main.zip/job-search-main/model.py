import sqlite3
import sys
class Model():
        mydb=db="myFileDb.db"
        def __init__(self):
            print("ok")
